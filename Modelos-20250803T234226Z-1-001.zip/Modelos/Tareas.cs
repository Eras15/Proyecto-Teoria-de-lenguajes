﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_de_Clase.Modelos
{
    public class Tareas
    {
        public int Id { get; set; }
        public string Descripcion { get; set; }
        public DateTime FechaLimite { get; set; }
    }
}
